package com.example.mybatisrealation.Server;

import com.example.mybatisrealation.bean.Orders;

import java.util.List;

/*
 * @Author yang
 * @Description //TODO $
 * @Date $ $
 **/
public interface OrderService {
    List<Orders> listAll();
}
