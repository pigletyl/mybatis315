package com.example.mybatisrealation.Server;

import com.example.mybatisrealation.bean.User;

public interface UserService {

        User findById(String id);

}
