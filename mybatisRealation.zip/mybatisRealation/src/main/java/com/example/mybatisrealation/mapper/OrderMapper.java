package com.example.mybatisrealation.mapper;

import com.example.mybatisrealation.bean.Orders;

import java.util.List;

public interface OrderMapper {

    List<Orders> listAll();
}
