package com.example.mybatisrealation.mapper;

import com.example.mybatisrealation.bean.SysLog;

/*
 * @Author yang
 * @Description //TODO $
 * @Date
 **/
public interface SysLogMapper {
    Integer insertLog (SysLog log);
}
