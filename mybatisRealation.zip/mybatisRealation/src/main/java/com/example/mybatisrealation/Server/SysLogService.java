package com.example.mybatisrealation.Server;

import com.example.mybatisrealation.bean.SysLog;

/*
 * @Author yang
 * @Description //TODO $
 * @Date
 **/
public interface SysLogService {
    Integer addLog (SysLog log);
}
