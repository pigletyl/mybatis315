package com.example.mybatisrealation.bean;

import lombok.Data;

import java.util.List;

/*
 * @Author yang
 * @Description //TODO $
 * @Date $ $
 **/
@Data
public class Student {
    private String id;
    private String name;
    private int age;
}
