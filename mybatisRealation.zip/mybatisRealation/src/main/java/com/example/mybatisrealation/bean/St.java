package com.example.mybatisrealation.bean;

import lombok.Data;

/*
 * @Author yang
 * @Description //TODO $
 * @Date
 **/
@Data
public class St {
    private String sname;
    private String tname;
}
