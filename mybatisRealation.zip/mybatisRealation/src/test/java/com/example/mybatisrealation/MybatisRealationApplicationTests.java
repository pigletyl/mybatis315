package com.example.mybatisrealation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybatisRealationApplicationTests {

    @Test
    void contextLoads() {
    }

}
